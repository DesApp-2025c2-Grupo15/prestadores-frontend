import React, { useEffect, useState } from "react"
import { Table, Button, Tag, Modal, message } from "antd"
import { EyeOutlined, PlusOutlined } from "@ant-design/icons"
import {
  getRecetas,
  getRecetaById,
  crearReceta,
  actualizarReceta,
  cambiarEstadoReceta,
} from "../services/recetas"
import Lista from "./Lista"
import EditorModal from "./EditorModal"

const Recetas = () => {
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(false)
  const [detalle, setDetalle] = useState(null)
  const [open, setOpen] = useState(false)
  const [loadingDetalle, setLoadingDetalle] = useState(false)

  // editor local state (mock)
  const [editorOpen, setEditorOpen] = useState(false)
  const [editorMode, setEditorMode] = useState("create") // 'create' | 'edit'
  const [editorItem, setEditorItem] = useState(null)

  const loadData = async () => {
    setLoading(true)
    try {
      const result = await getRecetas().catch(() => null)
      // soporta paginado o lista simple
      const items = result?.items ?? result ?? []
      setData(items)
    } catch (err) {
      console.error("Error al cargar recetas:", err)
      message.error("No se pudieron cargar recetas")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [])

  const showDetalle = async (id) => {
    setDetalle(null)
    try {
      setLoadingDetalle(true)
      const detail = await getRecetaById(id).catch(() => null)

      if (!detail) {
        // fallback: buscar en la lista local
        const local = data.find((r) => Number(r.id) === Number(id))
        if (local) {
          setDetalle({
            ...local,
            historialCambios: local.historial || local.historialCambios || [],
            afiliado: local.afiliado || {},
          })
          setOpen(true)
          return
        }
        message.error(`Detalle no disponible para la receta ${id}`)
        return
      }

      const normalized = {
        ...detail,
        historialCambios: detail.historial || detail.historialCambios || [],
        afiliado: detail.afiliado || {},
      }
      setDetalle(normalized)
      setOpen(true)
    } catch (error) {
      console.error("Error al traer detalle de receta:", error)
      message.error("No se pudo cargar el detalle")
    } finally {
      setLoadingDetalle(false)
    }
  }

  // Abre editor en modo create
  const handleOpenCreate = () => {
    setEditorMode("create")
    setEditorItem({ afiliadoId: "", medicamento: "", dosis: "", estado: "RECIBIDO", observacion: "" })
    setEditorOpen(true)
  }

  // Abre editor en modo edit
  const handleOpenEdit = async (id) => {
    // intenta pedir detalle real, si no existe usa local
    const detail = await getRecetaById(id).catch(() => null) || data.find((r) => r.id === id)
    setEditorMode("edit")
    setEditorItem(detail)
    setEditorOpen(true)
  }

  // guardar local (simula crear/editar)
  const handleSaveLocal = (values) => {
    if (editorMode === "create") {
      // generar id mock
      const newId = (data.reduce((m, it) => Math.max(m, Number(it.id || 0)), 0) || 0) + 1
      const newItem = { id: newId, afiliado: { id: values.afiliadoId }, ...values }
      setData((d) => [newItem, ...d])
      message.success("Receta creada (mock)")
    } else {
      // editar
      setData((d) => d.map((it) => (String(it.id) === String(editorItem.id) ? { ...it, ...values } : it)))
      message.success("Receta actualizada (mock)")
      // si modal detalle abierto y es la misma receta, refrescar detalle
      if (open && detalle?.id === editorItem?.id) {
        setDetalle((prev) => ({ ...prev, ...values }))
      }
    }
  }

  const handleDeleteLocal = (item) => {
    setData((d) => d.filter((it) => String(it.id) !== String(item.id)))
    message.success("Receta eliminada (mock)")
    if (open && detalle?.id === item.id) setOpen(false)
  }

  const handleCrear = async () => {
    // intenta crear contra API; si falla, abre editor mock
    try {
      await crearReceta({
        afiliadoId: 22,
        medicamento: "Amoxicilina 500mg",
        dosis: "1 cap. c/8h x 7d",
        estadoInicial: "RECIBIDO",
      })
      message.success("Receta creada (API)")
      loadData()
    } catch {
      message.info("API no disponible: abriendo editor mock")
      handleOpenCreate()
    }
  }

  const handleActualizar = async (id) => {
    // intenta actualizar en API; si falla usar editor mock
    try {
      await actualizarReceta(id, { dosis: "1 cap. c/8h x 10d" })
      message.success("Receta actualizada")
      loadData()
      if (open && detalle?.id === id) showDetalle(id)
    } catch {
      message.info("API no disponible: abrir editor mock")
      handleOpenEdit(id)
    }
  }

  const handleCambiarEstado = async (id, nuevoEstado = "EN_ANALISIS") => {
    try {
      await cambiarEstadoReceta(id, { nuevoEstado, usuario: "prestador.101" })
      message.success("Estado actualizado")
      loadData()
      if (open && detalle?.id === id) showDetalle(id)
    } catch {
      // fallback: editar localmente si existe en data
      setData((d) => d.map((it) => (String(it.id) === String(id) ? { ...it, estado: nuevoEstado } : it)))
      message.info("Estado actualizado (mock)")
      if (open && detalle?.id === id) setDetalle((prev) => ({ ...prev, estado: nuevoEstado }))
    }
  }

  const color = {
    RECIBIDO: "blue",
    EN_ANALISIS: "orange",
    OBSERVADO: "purple",
    APROBADO: "green",
    RECHAZADO: "red",
  }

  const columns = [
    { title: "ID", dataIndex: "id", key: "id" },
    { title: "Afiliado", render: (_, r) => `${r.afiliado?.nombre ?? r.afiliado?.id ?? "-"} ${r.afiliado?.apellido ?? ""}` },
    { title: "Medicamento", dataIndex: "medicamento", key: "medicamento" },
    { title: "Dosis", dataIndex: "dosis", key: "dosis" },
    { title: "Estado", dataIndex: "estado", render: (e) => <Tag color={color[e]}>{e}</Tag> },
    { title: "Fecha", dataIndex: "fechaCreacion", key: "fechaCreacion" },
    {
      title: "Detalle",
      key: "detalle",
      render: (_, record) => (
        <Button type="text" icon={<EyeOutlined />} onClick={() => showDetalle(record.id)} />
      ),
    },
    {
      title: "Acciones",
      key: "acciones",
      render: (_, record) => (
        <>
          <Button size="small" onClick={() => handleOpenEdit(record.id)} style={{ marginRight: 8 }}>
            Editar
          </Button>
          <Button size="small" onClick={() => handleCambiarEstado(record.id)} >
            Cambiar estado
          </Button>
        </>
      ),
    },
  ]

  return (
    <div style={{ padding: 16 }}>
      <h3>Recetas</h3>
      <div style={{ marginBottom: 12, textAlign: "right" }}>
        <Button type="primary" icon={<PlusOutlined />} onClick={handleCrear}>Crear receta</Button>
      </div>

      <Table rowKey="id" columns={columns} dataSource={data} loading={loading} pagination={{ pageSize: 10 }} bordered />

      <Lista
        open={open}
        onClose={() => setOpen(false)}
        loading={loadingDetalle}
        detalle={detalle}
        title="Detalle Receta"
        fields={[
          { key: "id", label: "ID" },
          { key: "tipo", label: "Tipo" },
          { key: "estado", label: "Estado" },
          { key: "medicamento", label: "Medicamento" },
          { key: "dosis", label: "Dosis" },
          { key: "fechaCreacion", label: "Fecha de creación" },
          {
            key: "afiliado",
            label: "Afiliado",
            subFields: [
              { key: "nombre", label: "Nombre" },
              { key: "apellido", label: "Apellido" },
              { key: "dni", label: "DNI" },
            ],
          },
          { key: "historialCambios", label: "Historial de cambios" },
        ]}
      />

      <EditorModal
        open={editorOpen}
        onClose={() => setEditorOpen(false)}
        mode={editorMode}
        initialValues={editorItem}
        title={editorMode === "create" ? "Crear Receta (mock)" : "Editar Receta (mock)"}
        onSave={handleSaveLocal}
        onDelete={editorMode === "edit" ? handleDeleteLocal : undefined}
      />
    </div>
  )
}

export default Recetas