import React from "react"

const TurnosPendientes = () => {
  return (<h3>Turnos Pendientes</h3>)
}

export default TurnosPendientes
