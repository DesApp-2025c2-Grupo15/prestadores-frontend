// ...existing code...
import React, { useEffect, useState } from "react"
import { Table, Button, Tag, Modal, message } from "antd"
import { EyeOutlined, PlusOutlined } from "@ant-design/icons"
import {
  getAutorizaciones,
  getAutorizacionById,
  crearAutorizacion,
  actualizarAutorizacion,
  cambiarEstadoAutorizacion,
} from "../services/autorizaciones"
import Lista from "./Lista"

const Autorizaciones = () => {
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(false)
  const [detalle, setDetalle] = useState(null)
  const [open, setOpen] = useState(false)
  const [loadingDetalle, setLoadingDetalle] = useState(false)

  const loadData = async () => {
    try {
      setLoading(true)
      const result = await getAutorizaciones()
      setData(result.items || [])
    } catch (error) {
      console.error("Error al traer autorizaciones:", error)
      message.error("No se pudieron cargar autorizaciones")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { loadData() }, [])

  const showDetalle = async (id) => {
    setDetalle(null)
    try {
      setLoadingDetalle(true)
      const detail = await getAutorizacionById(id)

      if (!detail) {
        message.error(`Detalle no disponible para la autorización ${id}`)
        return
      }

      const normalized = {
        ...detail,
        historialCambios: detail.historial || detail.historialCambios || [],
        afiliado: detail.afiliado || {},
      }
      setDetalle(normalized)
      setOpen(true)
    } catch (error) {
      console.error("Error al traer detalle de autorización:", error)
      message.error("No se pudo cargar detalle")
    } finally {
      setLoadingDetalle(false)
    }
  }

  const handleCrear = async () => {
    Modal.confirm({
      title: "Crear autorización de ejemplo",
      content: "Se creará una autorización de ejemplo para afiliado ID 31.",
      onOk: async () => {
        try {
          const body = {
            afiliadoId: 31,
            procedimiento: "Consulta de control",
            especialidad: "Clínica Médica",
            estadoInicial: "RECIBIDO",
          }
          await crearAutorizacion(body)
          message.success("Autorización creada")
          loadData()
        } catch (err) {
          console.error(err)
          message.error("Error al crear autorización")
        }
      },
    })
  }

  // ...handleActualizar y handleCambiarEstado (se mantienen)...

  const color = {
    RECIBIDO: "blue",
    EN_ANALISIS: "orange",
    OBSERVADO: "purple",
    APROBADO: "green",
    RECHAZADO: "red",
  }

  const columns = [
    { title: "ID", dataIndex: "id", key: "id" },
    { title: "Afiliado", render: (_, r) => `${r.afiliado?.nombre} ${r.afiliado?.apellido}` },
    { title: "Procedimiento", dataIndex: "procedimiento", key: "procedimiento" },
    { title: "Especialidad", dataIndex: "especialidad", key: "especialidad" },
    { title: "Estado", dataIndex: "estado", render: e => <Tag color={color[e]}>{e}</Tag> },
    { title: "Fecha", dataIndex: "fechaCreacion", key: "fechaCreacion"},
    {
      title: "Detalle",
      key: "detalle",
      render: (_, record) => (
        <Button type="text" icon={<EyeOutlined />} onClick={() => showDetalle(record.id)} />
      ),
    },
    {
          title: "Acciones",
          key: "acciones",
          render: (_, record) => (
            <>
              <Button size="small" onClick={() => handleActualizar(record.id)} style={{ marginRight: 8 }}>
                Editar
              </Button>
              <Button size="small" onClick={() => handleCambiarEstado(record.id)} >
                Cambiar estado
              </Button>
            </>
          ),
        },
    // acciones...
  ]

  return (
    <div style={{ padding: 16 }}>
      <h3 style={{ marginBottom: 16 }}>Autorizaciones</h3>

      <div style={{ marginBottom: 12, textAlign: "right" }}>
        <Button type="primary" icon={<PlusOutlined />} onClick={handleCrear}>Crear autorización</Button>
      </div>

      <Table rowKey="id" columns={columns} dataSource={data} loading={loading} pagination={{ pageSize: 10 }} bordered />

      <Lista
        open={open}
        onClose={() => setOpen(false)}
        loading={loadingDetalle}
        detalle={detalle}
        title="Detalle Autorización"
        fields={[
          { key: "id", label: "ID" },
          { key: "tipo", label: "Tipo" },
          { key: "estado", label: "Estado" },
          { key: "procedimiento", label: "Procedimiento" },
          { key: "especialidad", label: "Especialidad" },
          { key: "fechaCreacion", label: "Fecha de creación" },
          {
            key: "afiliado",
            label: "Afiliado",
            subFields: [
              { key: "nombre", label: "Nombre" },
              { key: "apellido", label: "Apellido" },
              { key: "dni", label: "DNI" },
            ],
          },
          { key: "historialCambios", label: "Historial de cambios" },
        ]}
      />
    </div>
  )
}

export default Autorizaciones
// ...existing code...