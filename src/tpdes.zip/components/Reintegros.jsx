import React, { useEffect, useState } from "react"
import { Table, Button, Tag, Modal, message } from "antd"
import { EyeOutlined, PlusOutlined } from "@ant-design/icons"
import {
  getReintegros,
  getReintegroById,
  crearReintegro,
  actualizarReintegro,
  cambiarEstadoReintegro,
} from "../services/reintegros"
import Lista from "./Lista"

const Reintegros = () => {
  const [data, setData] = useState([])
  const [loadingTabla, setLoadingTabla] = useState(false)
  const [loadingDetalle, setLoadingDetalle] = useState(false)
  const [detalle, setDetalle] = useState(null)
  const [open, setOpen] = useState(false)

  const loadData = async () => {
    try {
      setLoadingTabla(true)
      const result = await getReintegros()
      setData(result.items || [])
    } catch (error) {
      console.error("Error al traer reintegros:", error)
      message.error("No se pudieron cargar reintegros")
    } finally {
      setLoadingTabla(false)
    }
  }

  useEffect(() => { loadData() }, [])

  const showDetalle = async (id) => {
    setDetalle(null)
    try {
      setLoadingDetalle(true)
      const detail = await getReintegroById(id)

      if (!detail) {
        message.error(`Detalle no disponible para el reintegro ${id}`)
        return
      }

      const normalized = {
        ...detail,
        historialCambios: detail.historial || detail.historialCambios || [],
        afiliado: detail.afiliado || {},
      }
      setDetalle(normalized)
      setOpen(true)
    } catch (error) {
      console.error("Error al traer detalle de reintegro:", error)
      message.error("No se pudo cargar detalle")
    } finally {
      setLoadingDetalle(false)
    }
  }

  const handleCrear = async () => {
    Modal.confirm({
      title: "Crear reintegro de ejemplo",
      content: "Se creará un reintegro de ejemplo para afiliado ID 45.",
      onOk: async () => {
        try {
          const body = {
            afiliadoId: 45,
            prestacion: "Estudio diagnóstico",
            metodo: "Efectivo",
            monto: 30000,
            estadoInicial: "RECIBIDO",
          }
          await crearReintegro(body)
          message.success("Reintegro creado")
          loadData()
        } catch (err) {
          console.error(err)
          message.error("Error al crear reintegro")
        }
      },
    })
  }

  const handleActualizar = async (id) => {
    Modal.confirm({
      title: "Actualizar reintegro de ejemplo",
      content: "Se actualizarán datos del reintegro seleccionado.",
      onOk: async () => {
        try {
          await actualizarReintegro(id, { prestacion: "Fisioterapia", metodo: "Credito", monto: 95000 })
          message.success("Reintegro actualizado")
          loadData()
          if (open && detalle?.id === id) showDetalle(id)
        } catch (err) {
          console.error(err)
          message.error("Error al actualizar reintegro")
        }
      },
    })
  }

  const handleCambiarEstado = async (id, nuevoEstado = "EN_ANALISIS") => {
    Modal.confirm({
      title: `Cambiar estado a ${nuevoEstado}`,
      onOk: async () => {
        try {
          await cambiarEstadoReintegro(id, { nuevoEstado, usuario: "prestador.101" })
          message.success("Estado actualizado")
          loadData()
          if (open && detalle?.id === id) showDetalle(id)
        } catch (err) {
          console.error(err)
          message.error("Error al cambiar estado")
        }
      },
    })
  }

  const color = {
    RECIBIDO: "blue",
    EN_ANALISIS: "orange",
    OBSERVADO: "purple",
    APROBADO: "green",
    RECHAZADO: "red",
  }

  const columns = [
    { title: "ID", dataIndex: "id", key: "id" },
    { title: "Afiliado", render: (_, r) => `${r.afiliado?.nombre} ${r.afiliado?.apellido}` },
    { title: "Prestación", dataIndex: "prestacion", key: "prestacion" },
    { title: "Método", dataIndex: "metodo", key: "metodo" },
    { title: "Monto ($)", dataIndex: "monto", key: "monto" },
    { title: "Estado", dataIndex: "estado", render: e => <Tag color={color[e]}>{e}</Tag> },
    { title: "Fecha", dataIndex: "fechaCreacion", key: "fechaCreacion"},
    {
      title: "Detalle",
      key: "detalle",
      render: (_, record) => (
        <Button type="text" icon={<EyeOutlined />} onClick={() => showDetalle(record.id)} />
      ),
    },
    {
      title: "Acciones",
      key: "acciones",
      render: (_, record) => (
        <>
          <Button size="small" onClick={() => handleActualizar(record.id)} style={{ marginRight: 8 }}>
            Editar
          </Button>
          <Button size="small" onClick={() => handleCambiarEstado(record.id)} >
            Cambiar estado
          </Button>
        </>
      ),
    },
  ]

  return (
    <div style={{ padding: 16 }}>
      <h3 style={{ marginBottom: 16 }}>Reintegros</h3>

      <div style={{ marginBottom: 12, textAlign: "right" }}>
        <Button type="primary" icon={<PlusOutlined />} onClick={handleCrear}>Crear reintegro</Button>
      </div>

      <Table rowKey="id" columns={columns} dataSource={data} loading={loadingTabla} pagination={{ pageSize: 10 }} bordered />

      <Lista
        open={open}
        onClose={() => setOpen(false)}
        loading={loadingDetalle}
        detalle={detalle}
        title="Detalle Reintegro"
        fields={[
          { key: "id", label: "ID" },
          { key: "tipo", label: "Tipo" },
          { key: "estado", label: "Estado" },
          { key: "prestacion", label: "Prestación" },
          { key: "metodo", label: "Método" },
          { key: "monto", label: "Monto" },
          { key: "fechaCreacion", label: "Fecha de creación" },
          {
            key: "afiliado",
            label: "Afiliado",
            subFields: [
              { key: "nombre", label: "Nombre" },
              { key: "apellido", label: "Apellido" },
              { key: "dni", label: "DNI" },
            ],
          },
          { key: "historialCambios", label: "Historial de cambios" },
        ]}
      />
    </div>
  )
}

export default Reintegros