const Solicitudes = () => {
  return (
    <h2>Hola</h2>

  )
}

export default Solicitudes
